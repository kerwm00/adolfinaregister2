module.exports = async function(e){
console.log(`⚠️ Kerem_App_Error; `+e)}

module.exports.conf = {
name: "error"
}