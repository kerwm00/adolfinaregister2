[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Delicious+Handrawn&size=60&pause=1000&color=00F743&repeat=false&width=800&height=100&lines=Discord+Advanced+Register+Bot+%23By+Be%C5%9F)](https://git.io/typing-svg)

**Discord sunucularınızda kullanabileceğiniz setuplı son model v14 advanced kayıt botu.**
<br> </br>
[![Discord Presence](https://lanyard-profile-readme.vercel.app/api/928259219038302258?theme=light&hideDiscrim=false&hideBadges=false&bg=376074&borderRadius=30px&idleMessage=İletişim%20İçin%20Tıkla)](https://discord.com/users/928259219038302258)
<br> </br>
[![Discord Banner](https://cdn.discordapp.com/attachments/950167988127006821/1090467302719369246/2023-03-29_05-44-23_2.png)](https://discord.gg/luppux)
<br> </br>
<br> </br>
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Delicious+Handrawn&size=30&pause=1000&color=F70909&repeat=false&width=435&lines=%E2%9D%93+Kurulum+)](https://git.io/typing-svg)

- İlk olarak bilgisayarına [Node JS](https://nodejs.org/en/) `(en düşük v16)` indir.

- Daha sonra altyapıyı indirip `./beş_config.js` dosyasını doldur.
- sonrasında modülleri kurmak için terminale aşşağıdaki kodu yaz.

```diff
npm install
```
- `.setup` komudu ile kurulumu yapmaya başla!
- Bu kadar bot hazır.
- `.yardım:` komuduyla tüm komutlara ulaşabilirsin.
- örnek kurulum `.setup 1 @register staff` komuduyla kurulum yapabilirsiniz.
- tüm ID'leri görmek için `.setup` yazabilirsiniz.
- `.setup 1 sıfırla ` yaparsanız 1.ID'deki veriyi temizler.
<br> </br>
<br> </br>
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Delicious+Handrawn&size=30&pause=1000&color=F700E5&repeat=false&width=435&lines=%F0%9F%96%BC%EF%B8%8F+G%C3%B6rseller)](https://git.io/typing-svg)

<img  src="https://cdn.discordapp.com/attachments/950167988127006821/1090923072644722739/2023-03-30_11-49-54.png">
<img  src="https://cdn.discordapp.com/attachments/950167988127006821/1090923072153989140/2023-03-30_11-50-50.png">
<img  src="https://cdn.discordapp.com/attachments/950167988127006821/1090923070660808704/2023-03-30_11-52-39.png">
<img  src="https://cdn.discordapp.com/attachments/950167988127006821/1090923072430800956/2023-03-30_11-50-09.png">
<img  src="https://cdn.discordapp.com/attachments/950167988127006821/1090923070388187137/2023-03-30_11-53-32.png">
<img  src="https://cdn.discordapp.com/attachments/950167988127006821/1090923070899879946/2023-03-30_11-51-59.png">
<img  src="https://cdn.discordapp.com/attachments/950167988127006821/1090921905428631632/2023-03-30_11-51-45.png">
<img  src="https://cdn.discordapp.com/attachments/950167988127006821/1090921905642553384/2023-03-30_11-51-22.png">

  


- [Discord Profilim](https://discord.com/users/928259219038302258)

- Herhangi bir hata bulmanız durumunda bana ulaşabilirsiniz ^^
